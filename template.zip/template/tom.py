"""
Practice 1 -- Classify three systems (linearity & time-invariance).
- Reuse DiscreteSignal / LTISystem from the offline (imported below).
- Complete the TODOs. Do NOT use numpy.convolve / scipy.signal.
- A system is LTI only if BOTH tests give ~0.
Expected (answer key): A -> (0, 0) ; square -> (24, 0) ; reverse -> (0, 3).
Write your own code replacing each `raise NotImplementedError`, then compare
with the commented reference just above it.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def max_absolute_difference(a, b):
    # TODO: largest |a[n] - b[n]| over the combined range of a and b.
    #
    # reference:
    #   start = min(a.start_time, b.start_time)
    #   end   = max(a.end_time,   b.end_time)
    #   return max(abs(a.get_value_at_time(t) - b.get_value_at_time(t))
    #              for t in range(start, end + 1))
    raise NotImplementedError


# ---- Generic property testers (must work for ANY callable system) ----
def test_linearity(apply_system, x1, x2, a, b):
    # TODO: return max| apply_system(a*x1 + b*x2) - (a*apply_system(x1) + b*apply_system(x2)) |
    #
    # reference:
    #   combined = x1.multiply(a).add(x2.multiply(b))            # a*x1 + b*x2
    #   lhs = apply_system(combined)                             # T{a*x1 + b*x2}
    #   rhs = apply_system(x1).multiply(a).add(apply_system(x2).multiply(b))  # a*T{x1}+b*T{x2}
    #   return max_absolute_difference(lhs, rhs)
    raise NotImplementedError


def test_time_invariance(apply_system, x, k):
    # TODO: return max| apply_system(x shifted by k) - (apply_system(x) shifted by k) |
    #
    # reference:
    #   lhs = apply_system(x.shift(k))     # T{x[n-k]}  (shift first, then run)
    #   rhs = apply_system(x).shift(k)     # y[n-k]     (run first, then shift)
    #   return max_absolute_difference(lhs, rhs)
    raise NotImplementedError


# ---- The three systems ----
def system_square(x):
    # TODO: y[n] = x[n]**2  (build and return a new DiscreteSignal)
    #
    # reference:
    #   out = DiscreteSignal(x.start_time, x.end_time)
    #   for n in x.times():
    #       out.set_value_at_time(n, x.get_value_at_time(n) ** 2)
    #   return out
    raise NotImplementedError


def system_reverse(x):
    # TODO: y[n] = x[-n]  (note: the time range flips sign)
    #
    # reference (value at n moves to position -n; range [s,e] -> [-e,-s]):
    #   out = DiscreteSignal(-x.end_time, -x.start_time)
    #   for n in x.times():
    #       out.set_value_at_time(-n, x.get_value_at_time(n))
    #   return out
    raise NotImplementedError


def main():
    x1 = make_signal(-2, 1, [2, 1, -1, 3])
    x2 = make_signal(0, 3, [1, 0, 2, -2])
    a, b, k = 1.5, -2.0, 2

    h = make_signal(0, 2, [1.0, -1.0, 0.5])
    system_a = LTISystem(h)

    # TODO: fill these in using the testers above.
    #
    # reference:
    #   print("=== System A (LTI, via LTISystem.output) ===")
    #   print("linearity:", test_linearity(system_a.output, x1, x2, a, b),
    #         " time-invariance:", test_time_invariance(system_a.output, x1, k))
    #   print("=== System S (squarer) ===")
    #   print("linearity:", test_linearity(system_square, x1, x2, a, b),
    #         " time-invariance:", test_time_invariance(system_square, x1, k))
    #   print("=== System R (time reversal) ===")
    #   print("linearity:", test_linearity(system_reverse, x1, x2, a, b),
    #         " time-invariance:", test_time_invariance(system_reverse, x1, k))
    #   print("System S fails LINEARITY (squaring); System R fails TIME-INVARIANCE "
    #         "(mirroring); only System A is LTI.")
    print("=== System A (LTI, via LTISystem.output) ===")
    print("linearity:", None, " time-invariance:", None)

    print("=== System S (squarer) ===")
    print("linearity:", None, " time-invariance:", None)

    print("=== System R (time reversal) ===")
    print("linearity:", None, " time-invariance:", None)


if __name__ == "__main__":
    main()



"""
Practice 2 -- Distributivity / parallel connection: x*(h1+h2) = x*h1 + x*h2.
- Reuse DiscreteSignal / LTISystem. No numpy.convolve / scipy.signal.
Expected (answer key): max diff = 0 ; y over n=-1..3 = [2.0, 3.5, -3.0, 6.5, -1.5].
Write your own code replacing each `raise NotImplementedError` / `None`, then
compare with the commented reference just above it.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def max_absolute_difference(a, b):
    # TODO: largest |a[n] - b[n]| over the combined range.
    #
    # reference (careful: range end is inclusive, so use end + 1):
    #   start = min(a.start_time, b.start_time)
    #   end   = max(a.end_time,   b.end_time)
    #   return max(abs(a.get_value_at_time(t) - b.get_value_at_time(t))
    #              for t in range(start, end + 1))
    raise NotImplementedError


def main():
    x = make_signal(-1, 2, [1, 2, -1, 3])
    h1 = make_signal(0, 1, [1.0, 0.5])
    h2 = make_signal(0, 1, [1.0, -1.0])

    system_a = LTISystem(h1)
    system_b = LTISystem(h2)

    # TODO: parallel = output of A on x, ADDED to output of B on x.
    #   reference:  parallel_output = system_a.output(x).add(system_b.output(x))
    parallel_output = None

    # TODO: combined = single system with impulse response (h1 + h2), applied to x.
    #   reference:  combined_output = LTISystem(h1.add(h2)).output(x)
    combined_output = None

    # TODO: max difference between the two.
    #   reference:  difference = max_absolute_difference(parallel_output, combined_output)
    difference = None

    # TODO: print both signals (use .values) and a one-line conclusion.
    #   reference:
    #     print("parallel output:", parallel_output.values)
    #     print("combined output:", combined_output.values)
    #     print("max difference:", difference)
    #     print("Convolution distributes over addition: x*(h1+h2) = x*h1 + x*h2.")
    print("parallel output:", None)
    print("combined  output:", None)
    print("max difference:", difference)


if __name__ == "__main__":
    main()


"""
Practice 3 -- Cascade order independence: x*h1*h2 = x*h2*h1 = x*(h1*h2).
- Reuse DiscreteSignal / LTISystem. No numpy.convolve / scipy.signal.
- Trick: h1*h2 without a convolve function is just LTISystem(h1).output(h2).
Expected (answer key): both max diffs = 0 ; h1*h2 = [1, -0.5, -0.5] on n=0..2 ;
cascade y over n=-1..4 = [1.0, 1.5, -2.5, 2.5, -1.0, -1.5].
Write your own code replacing each `raise NotImplementedError` / `None`, then
compare with the commented reference just above it.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def max_absolute_difference(a, b):
    # TODO: largest |a[n] - b[n]| over the combined range.
    #
    # reference:
    #   start = min(a.start_time, b.start_time)
    #   end   = max(a.end_time,   b.end_time)
    #   return max(abs(a.get_value_at_time(t) - b.get_value_at_time(t))
    #              for t in range(start, end + 1))
    raise NotImplementedError


def cascade(first_system, second_system, x):
    # TODO: apply first_system.output, then second_system.output; return the final signal.
    #
    # reference:
    #   intermediate = first_system.output(x)
    #   final = second_system.output(intermediate)
    #   return final
    raise NotImplementedError


def main():
    x = make_signal(-1, 2, [1, 2, -1, 3])
    h1 = make_signal(0, 1, [1.0, 0.5])
    h2 = make_signal(0, 1, [1.0, -1.0])

    system_a = LTISystem(h1)
    system_b = LTISystem(h2)

    # TODO: cascade in both orders.
    #   reference:
    #     forward = cascade(system_a, system_b, x)
    #     reverse = cascade(system_b, system_a, x)
    forward = None
    reverse = None

    # TODO: equivalent single response h1*h2 = LTISystem(h1).output(h2), then apply to x.
    #   reference:
    #     combined_response = system_a.output(h2)          # this is h1 * h2
    #     direct = LTISystem(combined_response).output(x)
    combined_response = None
    direct = None

    # TODO: print the two max differences and a one-line conclusion.
    #   reference:
    #     print("max diff (A->B vs B->A):", max_absolute_difference(forward, reverse))
    #     print("max diff (A->B vs single h1*h2):", max_absolute_difference(forward, direct))
    #     print("Cascade order does not matter: x*h1*h2 = x*h2*h1 = x*(h1*h2).")
    print("max diff (A->B vs B->A):", None)
    print("max diff (A->B vs single h1*h2):", None)


if __name__ == "__main__":
    main()


"""
Practice 4 -- BIBO stability bound: max|y| <= (sum|h|) * max|x|.
- Reuse DiscreteSignal / LTISystem. No numpy.convolve / scipy.signal.
Expected (answer key): sum|h| = 0.9375 ; peak|y| = 0.9375 ; bound holds (equality here).
Write your own code replacing each `None`, then compare with the commented
reference just above it.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def main():
    h = make_signal(0, 3, [0.5, -0.25, 0.125, -0.0625])
    x = make_signal(-1, 3, [1, -1, 1, -1, 1])   # |x[n]| <= 1

    # TODO: stability sum S = sum of |h[k]| over h.values
    #   reference:  stability_sum = sum(abs(v) for v in h.values)
    stability_sum = None

    # TODO: y = LTISystem(h).output(x); peak = max |y[n]|
    #   reference:
    #     y = LTISystem(h).output(x)
    #     peak_output = max(abs(y.get_value_at_time(n)) for n in y.times())
    peak_output = None

    # TODO: max input magnitude
    #   reference:  peak_input = max(abs(v) for v in x.values)
    peak_input = None

    # TODO: print S, peak, whether the bound holds, and a one-line conclusion.
    #   reference:
    #     print("sum|h| =", stability_sum)
    #     print("peak|y| =", peak_output)
    #     print("bound holds:", peak_output <= stability_sum * peak_input + 1e-12)
    #     print("Finite sum|h| => BIBO stable; gain bound max|y| <= (sum|h|)*max|x| holds.")
    print("sum|h| =", stability_sum)
    print("peak|y| =", peak_output)
    print("bound holds:", None)


if __name__ == "__main__":
    main()


"""
Practice 5 -- Step response recovers the impulse response: s[n] - s[n-1] = h[n].
- Reuse DiscreteSignal / LTISystem. No numpy.convolve / scipy.signal.
Expected (answer key): step response over 0..5 = [1.0, 0.0, 0.5, 0.5, 0.5, 0.5] ;
first difference of s equals h=[1,-1,0.5] on n=0..2, max diff = 0.
Write your own code replacing each `raise NotImplementedError` / `None`, then
compare with the commented reference just above it.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def max_absolute_difference_in_range(a, b, start_time, end_time):
    # TODO: largest |a[n] - b[n]| for start_time <= n <= end_time.
    #
    # reference:
    #   return max(abs(a.get_value_at_time(n) - b.get_value_at_time(n))
    #              for n in range(start_time, end_time + 1))
    raise NotImplementedError


def first_difference(sig):
    # TODO: return a new signal r[n] = sig[n] - sig[n-1] over sig's range.
    #
    # reference (get_value_at_time returns 0 outside the range, so n-1 is safe):
    #   out = DiscreteSignal(sig.start_time, sig.end_time)
    #   for n in sig.times():
    #       out.set_value_at_time(n, sig.get_value_at_time(n) - sig.get_value_at_time(n - 1))
    #   return out
    raise NotImplementedError


def main():
    h = make_signal(0, 2, [1.0, -1.0, 0.5])

    # unit step u[n]: 1 for n >= 0, stored over a window covering the whole response
    step = make_signal(-3, 12, [0, 0, 0] + [1] * 13)

    # TODO: s = LTISystem(h).output(step)
    #   reference:  step_response = LTISystem(h).output(step)
    step_response = None

    # TODO: r = first_difference(step_response)
    #   reference:  recovered = first_difference(step_response)
    recovered = None

    # TODO: max diff between recovered and h on n = 0..2
    #   reference:  difference = max_absolute_difference_in_range(recovered, h, 0, 2)
    difference = None

    # TODO: print s[n] on 0..5, the difference, and a one-line conclusion.
    #   reference:
    #     print("step response s[n], n=0..5:",
    #           [step_response.get_value_at_time(n) for n in range(0, 6)])
    #     print("recovered h vs true h, max diff on 0..2:", difference)
    #     print("Differencing the step response recovers h[n]; accumulator and "
    #           "first difference are inverse systems.")
    print("step response s[n], n=0..5:", None)
    print("recovered h vs true h, max diff on 0..2:", difference)


if __name__ == "__main__":
    main()


"""
Practice 6 -- Convolution is commutative: x*h = h*x.  (Lecture: "a*b = b*a")
- Reuse DiscreteSignal / LTISystem. No numpy.convolve / scipy.signal.
- Key idea: LTISystem(h).output(x) and LTISystem(x).output(h) must match.
Expected: both = [1.0, 2.5, -1.0, 0.5, 2.5, -3.0] on n=-1..4 ; max diff = 0.
Write your own code replacing each `raise NotImplementedError` / `None`, then
compare with the commented reference just above it.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def max_absolute_difference(a, b):
    # TODO: largest |a[n] - b[n]| over the combined range.
    #
    # reference:
    #   start = min(a.start_time, b.start_time)
    #   end   = max(a.end_time,   b.end_time)
    #   return max(abs(a.get_value_at_time(t) - b.get_value_at_time(t))
    #              for t in range(start, end + 1))
    raise NotImplementedError


def main():
    x = make_signal(-1, 2, [1, 2, -1, 3])
    h = make_signal(0, 2, [1.0, 0.5, -1.0])

    # TODO: convolve x with h  (h is the impulse response, x is the input).
    #   reference:  x_conv_h = LTISystem(h).output(x)
    x_conv_h = None

    # TODO: convolve the other way  (swap the roles).
    #   reference:  h_conv_x = LTISystem(x).output(h)
    h_conv_x = None

    # TODO: max difference between the two.
    #   reference:  difference = max_absolute_difference(x_conv_h, h_conv_x)
    difference = None

    # TODO: print both and a one-line conclusion.
    #   reference:
    #     print("x * h:", x_conv_h.values)
    #     print("h * x:", h_conv_x.values)
    #     print("max difference:", difference)
    #     print("Convolution is commutative: x*h = h*x.")
    print("x * h:", None)
    print("h * x:", None)
    print("max difference:", difference)


if __name__ == "__main__":
    main()


"""
Practice 7 -- Convolution = polynomial multiplication.  (Lecture example)
- Convolving coefficient sequences gives the coefficients of the product polynomial.
- A(z) = 1 + 3z + 2z^2 + 5z^3 + 4z^4   -> a = [1, 3, 2, 5, 4]
- B(z) = 2 -  z + 4z^2 +  z^3 + 3z^4   -> b = [2,-1, 4, 1, 3]
- c[n] = sum_k a[k] b[n-k]  is the coefficient of z^n in A(z)B(z).
- No numpy.convolve / scipy.signal (and no np.polymul -- that IS convolution).
Expected: c = [2, 5, 5, 21, 17, 27, 27, 19, 12] on n=0..8 ; c[4] = 17 (lecture).
Write your own code replacing each `raise NotImplementedError` / `None`.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def coefficient_at(a, b, n):
    # TODO: compute c[n] = sum_k a[k] * b[n-k] directly (the sliding multiply-add).
    #       Only k inside a's stored range matter (elsewhere a[k] = 0).
    #
    # reference:
    #   total = 0.0
    #   for k in a.times():
    #       total += a.get_value_at_time(k) * b.get_value_at_time(n - k)
    #   return total
    raise NotImplementedError


def main():
    a = make_signal(0, 4, [1, 3, 2, 5, 4])
    b = make_signal(0, 4, [2, -1, 4, 1, 3])

    # The product of two degree-4 polynomials has degree 8 -> c over n = 0..8.
    # TODO: build c[n] for n = 0..8 using coefficient_at (or LTISystem).
    #   reference (direct sum, matches the lecture's "criss-cross" pairing):
    #     c = make_signal(0, 8, [coefficient_at(a, b, n) for n in range(0, 9)])
    #   reference (shortcut using your class -- convolution IS this):
    #     c = LTISystem(a).output(b)
    c = None

    # TODO: print all coefficients and the single lecture value c[4].
    #   reference:
    #     print("product coefficients c[n]:", c.values)
    #     print("c[4] =", c.get_value_at_time(4), "(lecture: 17)")
    #     print("Convolution of coefficient sequences = polynomial multiplication.")
    print("product coefficients c[n]:", None)


if __name__ == "__main__":
    main()


"""
Practice 8 -- Any signal is a sum of shifted, scaled impulses.
    x[n] = sum_k x[k] * delta[n - k]                (Lecture: sifting/decomposition)
- Rebuild a signal from scratch by adding one scaled impulse per sample,
  then check it equals the original.
- Reuse DiscreteSignal. No numpy.convolve / scipy.signal.
Expected: reconstructed = original = [2, -1, 3, 1] ; max diff = 0.
Write your own code replacing each `raise NotImplementedError` / `None`.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def max_absolute_difference(a, b):
    # TODO: largest |a[n] - b[n]| over the combined range.
    #
    # reference:
    #   start = min(a.start_time, b.start_time)
    #   end   = max(a.end_time,   b.end_time)
    #   return max(abs(a.get_value_at_time(t) - b.get_value_at_time(t))
    #              for t in range(start, end + 1))
    raise NotImplementedError


def scaled_shifted_impulse(start_time, end_time, position, height):
    # TODO: return a signal that is `height` at n = position and 0 elsewhere
    #       (this is height * delta[n - position]).
    #
    # reference:
    #   imp = DiscreteSignal(start_time, end_time)
    #   imp.set_value_at_time(position, height)
    #   return imp
    raise NotImplementedError


def main():
    x = make_signal(-1, 2, [2, -1, 3, 1])

    # TODO: rebuild x by summing one scaled impulse per sample of x.
    #   reference:
    #     recon = DiscreteSignal(x.start_time, x.end_time)
    #     for k in x.times():
    #         piece = scaled_shifted_impulse(x.start_time, x.end_time,
    #                                        k, x.get_value_at_time(k))
    #         recon = recon.add(piece)
    recon = None

    # TODO: max difference between recon and x.
    #   reference:  difference = max_absolute_difference(recon, x)
    difference = None

    # TODO: print original, reconstruction, difference, and a one-line conclusion.
    #   reference:
    #     print("original:     ", x.values)
    #     print("reconstructed:", recon.values)
    #     print("max difference:", difference)
    #     print("Every signal is a sum of shifted, scaled impulses.")
    print("original:     ", x.values)
    print("reconstructed:", None)
    print("max difference:", difference)


if __name__ == "__main__":
    main()



"""
Practice 9 -- A pure delay is convolution with a shifted impulse.
    h[n] = delta[n - d]   =>   y[n] = (x * h)[n] = x[n - d]     (Lecture: pure delay)
- Convolving with delta[n-d] just shifts the input right by d.
- Reuse DiscreteSignal / LTISystem. No numpy.convolve / scipy.signal.
Given: x over 0..3 = [1, 2, -1, 3], delay d = 3.
Expected: y = x delayed by 3 = [1, 2, -1, 3] on n=3..6 ; max diff from x.shift(3) = 0.
Write your own code replacing each `raise NotImplementedError` / `None`.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def max_absolute_difference(a, b):
    # TODO: largest |a[n] - b[n]| over the combined range.
    #
    # reference:
    #   start = min(a.start_time, b.start_time)
    #   end   = max(a.end_time,   b.end_time)
    #   return max(abs(a.get_value_at_time(t) - b.get_value_at_time(t))
    #              for t in range(start, end + 1))
    raise NotImplementedError


def main():
    x = make_signal(0, 3, [1, 2, -1, 3])
    d = 3

    # TODO: build the delay impulse response h[n] = delta[n - d]
    #       (a single 1 at n = d, zero elsewhere).
    #   reference:  h = make_signal(d, d, [1.0])
    h = None

    # TODO: run x through the delay system.
    #   reference:  y = LTISystem(h).output(x)
    y = None

    # TODO: the expected answer is simply x shifted right by d.
    #   reference:  expected = x.shift(d)
    expected = None

    # TODO: compare them.
    #   reference:  difference = max_absolute_difference(y, expected)
    difference = None

    # TODO: print y, expected, difference, and a one-line conclusion.
    #   reference:
    #     print("delayed output y[n]:", y.values, "over", y.start_time, "..", y.end_time)
    #     print("x shifted by d:     ", expected.values)
    #     print("max difference:", difference)
    #     print("Convolving with delta[n-d] delays the signal by d samples.")
    print("delayed output y[n]:", None)
    print("max difference:", difference)


if __name__ == "__main__":
    main()



"""
Practice 10 -- Decaying-echo system h[n] = alpha^n u[n], 0 < alpha < 1.
    (Lecture: alpha controls how quickly echoes fade.)
- This system also obeys the recursion  y[n] = x[n] + alpha * y[n-1].
- Verify the convolution output matches the recursion on an observation window.
- Reuse DiscreteSignal / LTISystem. No numpy.convolve / scipy.signal.
Given: alpha = 0.5, x over 0..3 = [1, 2, -1, 3], store h for n = 0..15, window 0..10.
Expected: both give [1.0, 2.5, 0.25, 3.125, 1.5625, 0.7813, ...] ; max diff = 0.
Write your own code replacing each `raise NotImplementedError` / `None`.
"""

from signal_lti import DiscreteSignal, LTISystem


def make_signal(start_time, end_time, values):
    signal = DiscreteSignal(start_time, end_time)
    for offset, value in enumerate(values):
        signal.set_value_at_time(start_time + offset, value)
    return signal


def main():
    alpha = 0.5
    N = 15            # store enough of the (infinite) impulse response
    OBS = 10          # compare on n = 0..OBS

    x = make_signal(0, 3, [1, 2, -1, 3])

    # TODO: build h[n] = alpha^n for n = 0..N  (this is alpha^n * u[n], truncated).
    #   reference:  h = make_signal(0, N, [alpha ** n for n in range(N + 1)])
    h = None

    # TODO: convolution output y = x * h.
    #   reference:  y_conv = LTISystem(h).output(x)
    y_conv = None

    # TODO: build the recursion output y[n] = x[n] + alpha * y[n-1] on n = 0..OBS.
    #       (get_value_at_time returns 0 before the start, so y[-1] = 0 automatically.)
    #   reference:
    #     y_rec = DiscreteSignal(0, OBS)
    #     for n in range(0, OBS + 1):
    #         y_rec.set_value_at_time(n, x.get_value_at_time(n)
    #                                    + alpha * y_rec.get_value_at_time(n - 1))
    y_rec = None

    # TODO: max |y_conv[n] - y_rec[n]| for n = 0..OBS.
    #   reference:
    #     difference = max(abs(y_conv.get_value_at_time(n) - y_rec.get_value_at_time(n))
    #                      for n in range(0, OBS + 1))
    difference = None

    # TODO: print both and a one-line conclusion.
    #   reference:
    #     print("convolution y[0..10]:", [y_conv.get_value_at_time(n) for n in range(0, OBS+1)])
    #     print("recursion   y[0..10]:", [y_rec.get_value_at_time(n)  for n in range(0, OBS+1)])
    #     print("max difference:", difference)
    #     print("The echo system h=alpha^n u[n] equals the recursion y[n]=x[n]+alpha*y[n-1].")
    print("max difference:", difference)


if __name__ == "__main__":
    main()
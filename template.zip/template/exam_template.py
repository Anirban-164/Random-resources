# ================================================================
# CSE220 — EXAM TEMPLATE
# Built on DiscreteSignal and LTISystem from the offline.
# Rename to your student ID before submitting, e.g. 2305xxx.py
#
# QUICK REFERENCE
# ───────────────────────────────────────────────────────────────
# SIGNAL CONSTRUCTION
#   make_signal(start, end, values)
#
# PATCHED DiscreteSignal METHODS  (monkey-patched below)
#   .subtract(other)          →  x[n] - y[n]
#   .energy()                 →  Σ |x[n]|²
#   .l2_norm()                →  √energy
#   .cross_correlate(other)   →  R_xy[m]
#
# PATCHED LTISystem METHODS  (monkey-patched below)
#   .is_causal()
#   .verify_linearity(x1, x2, a, b)
#   .verify_time_invariance(x, k)
#   .step_response(n_start, n_end)
#
# UTILITY
#   convolve_signals(a, b)
#   max_absolute_difference_in_range(a, b, start, end)
#
# SYSTEM COMBINATION
#   apply_cascade(systems, x)             →  list of outputs
#   cascade_equivalent(systems)           →  h_eq signal
#   parallel(sys1, sys2, x)               →  (y1, y2, y_total)
#   pre_then_parallel(sys0, sys1, sys2, x)→  (v, y1, y2, y_total)
#   two_cascades_parallel(sa1, sa2, sb, x)→  (v_a, y_a, y_b, y_total)
#   parallel_then_cascade(s1, s2, s3, x)  →  (v, y)
#   cascade_then_parallel(s1, s2, s3, x)  →  (y1, y2, y_total)
#
# GENERIC TESTS  (accept any callable, not just LTISystem)
#   test_linearity(apply_system, x1, x2, a, b)
#   test_time_invariance(apply_system, x, k)
#
# SIGNAL ANALYSIS
#   even_part(x), odd_part(x)
#   matched_filter(template)  →  LTISystem
#   find_peak(signal, start, end)  →  int
#
# NON-LTI SYSTEM STUBS
#   system_b(x)   →  n · x[n]       (linear, NOT time-invariant)
#   system_c(x)   →  x[n]²          (time-invariant, NOT linear)
#   system_d(x)   →  x[n]·cos(πn/4) (linear, NOT time-invariant)
#
# DISPLAY
#   print_signal(sig, name, start, end)
#   print_comparison(col_names, signals, start, end)
#   plot_signals(signals_and_titles, save_path, obs_start, obs_end)
# ================================================================

import os
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-cache")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from signal_lti import DiscreteSignal, LTISystem, readable_time_ticks


# ================================================================
# PATCH: add methods to DiscreteSignal
# (avoids modifying signal_lti.py; safe to call anywhere after this)
# ================================================================

def _subtract(self, other):
    """Return x[n] - other[n] over the union of both time ranges."""
    start  = min(self.start_time, other.start_time)
    end    = max(self.end_time,   other.end_time)
    result = DiscreteSignal(start, end)
    for t in result.times():
        result.set_value_at_time(
            t, self.get_value_at_time(t) - other.get_value_at_time(t)
        )
    return result

def _energy(self):
    """Return total signal energy E = Σ |x[n]|²."""
    return float(np.sum(self.x ** 2))

def _l2_norm(self):
    """Return L2 norm = √(energy)."""
    return float(np.sqrt(self.energy()))

def _cross_correlate(self, other):
    """Return R_xy[m] = Σ_k x[k]·y[k+m].
    Uses the identity R_xy = (x[-n] * y)[m]."""
    return LTISystem(self.reverse()).output(other)

DiscreteSignal.subtract        = _subtract
DiscreteSignal.energy          = _energy
DiscreteSignal.l2_norm         = _l2_norm
DiscreteSignal.cross_correlate = _cross_correlate


# ================================================================
# PATCH: add methods to LTISystem
# ================================================================

def _is_causal(self):
    """Return True if h[n] = 0 for all n < 0."""
    return all(t >= 0 for t, _ in self.h.nonzero_samples())

def _verify_linearity(self, x1, x2, a, b):
    """Return max |T{a·x1 + b·x2} - a·T{x1} - b·T{x2}|."""
    lhs = self.output(x1.multiply(a).add(x2.multiply(b)))
    rhs = self.output(x1).multiply(a).add(self.output(x2).multiply(b))
    return _max_diff(lhs, rhs)

def _verify_time_invariance(self, x, k):
    """Return max |T{x[n-k]} - y[n-k]| where y = T{x}."""
    y_shifted = self.output(x).shift(k)
    y2        = self.output(x.shift(k))
    return _max_diff(y_shifted, y2)

def _step_response(self, n_start, n_end):
    """Return s = T{u} where u[n] = 1 for n >= 0, else 0, over [n_start, n_end].
    Also prints the first-difference verification: s[n] - s[n-1] = h[n]."""
    u = DiscreteSignal(n_start, n_end)
    for n in range(max(0, n_start), n_end + 1):
        u.set_value_at_time(n, 1.0)
    s = self.output(u)
    max_err = max(
        abs(s.get_value_at_time(n) - s.get_value_at_time(n - 1)
            - self.h.get_value_at_time(n))
        for n in self.h.times()
    )
    print(f"Step response check  max|s[n]-s[n-1]-h[n]| = {max_err:.2e}")
    return s

LTISystem.is_causal              = _is_causal
LTISystem.verify_linearity       = _verify_linearity
LTISystem.verify_time_invariance = _verify_time_invariance
LTISystem.step_response          = _step_response


# ================================================================
# SECTION 1 — SIGNAL CONSTRUCTION
# ================================================================

def make_signal(start_time, end_time, values):
    """Build a DiscreteSignal from a range and a flat list of values."""
    sig = DiscreteSignal(start_time, end_time)
    for i, v in enumerate(values):
        sig.set_value_at_time(start_time + i, v)
    return sig


# ================================================================
# SECTION 2 — CORE UTILITY FUNCTIONS
# ================================================================

def _max_diff(a, b):
    """Internal: max |a[n] - b[n]| over the union of both ranges."""
    start = min(a.start_time, b.start_time)
    end   = max(a.end_time,   b.end_time)
    return max(
        abs(a.get_value_at_time(n) - b.get_value_at_time(n))
        for n in range(start, end + 1)
    )

def max_absolute_difference_in_range(a, b, start, end):
    """Return max |a[n] - b[n]| over the inclusive range [start, end]."""
    return max(
        abs(a.get_value_at_time(n) - b.get_value_at_time(n))
        for n in range(start, end + 1)
    )

def convolve_signals(a, b):
    """Return the convolution a * b by treating a as the impulse response."""
    return LTISystem(a).output(b)


# ================================================================
# SECTION 3 — SYSTEM COMBINATION FUNCTIONS
# ================================================================

def apply_cascade(systems, x):
    """Apply a list of LTISystems in order to input x.
    Returns a list of DiscreteSignals: [v1, v2, ..., y].
    The final output is always outputs[-1]."""
    outputs = []
    current = x
    for sys in systems:
        current = sys.output(current)
        outputs.append(current)
    return outputs


def cascade_equivalent(systems):
    """Return h_eq = h1 * h2 * ... * hN by convolving all impulse responses.
    Pass the result to LTISystem(h_eq) to get the single equivalent system."""
    h_eq = systems[0].h
    for sys in systems[1:]:
        h_eq = convolve_signals(h_eq, sys.h)
    return h_eq


def parallel(sys1, sys2, input_signal):
    """Apply sys1 and sys2 in parallel.
    Returns (y1, y2, y_total) where y_total = y1 + y2."""
    y1 = sys1.output(input_signal)
    y2 = sys2.output(input_signal)
    return y1, y2, y1.add(y2)


def pre_then_parallel(sys0, sys1, sys2, x):
    """Shared pre-processor sys0, then two parallel branches sys1 and sys2.

    Topology:
                  ┌── sys1 ──┐
      x ── sys0 ──┤           ├──(+)── y
                  └── sys2 ──┘

    Returns (v, y1, y2, y_total) where v = sys0.output(x)."""
    v  = sys0.output(x)
    y1 = sys1.output(v)
    y2 = sys2.output(v)
    return v, y1, y2, y1.add(y2)


def two_cascades_parallel(sys_a1, sys_a2, sys_b, x):
    """Chain A (sys_a1 → sys_a2) in parallel with single system sys_b.

    Topology:
            ┌── sys_a1 ── sys_a2 ──┐
      x ────┤                       ├──(+)── y
            └──────── sys_b ────────┘

    Returns (v_a, y_a, y_b, y_total)."""
    v_a = sys_a1.output(x)
    y_a = sys_a2.output(v_a)
    y_b = sys_b.output(x)
    return v_a, y_a, y_b, y_a.add(y_b)


def parallel_then_cascade(sys1, sys2, sys3, x):
    """Parallel pair (sys1 || sys2) feeding shared post-processor sys3.

    Topology:
            ┌── sys1 ──┐
      x ────┤           ├──(+)── sys3 ── y
            └── sys2 ──┘

    Returns (v, y) where v is the summed parallel output."""
    v = sys1.output(x).add(sys2.output(x))
    y = sys3.output(v)
    return v, y


def cascade_then_parallel(sys1, sys2, sys3, x):
    """Equivalent to parallel_then_cascade by the distributive law.
    Post-processor sys3 applied separately inside each branch.

    Topology:
            ┌── sys1 ── sys3 ──┐
      x ────┤                   ├──(+)── y
            └── sys2 ── sys3 ──┘

    Returns (y1, y2, y_total)."""
    y1 = sys3.output(sys1.output(x))
    y2 = sys3.output(sys2.output(x))
    return y1, y2, y1.add(y2)


# ================================================================
# SECTION 4 — GENERIC VERIFICATION FUNCTIONS
# (accept any callable, not just LTISystem instances)
# ================================================================

def test_linearity(apply_system, x1, x2, a, b):
    """Return max |T{a·x1 + b·x2} - a·T{x1} - b·T{x2}|.
    apply_system is any callable: DiscreteSignal -> DiscreteSignal."""
    lhs = apply_system(x1.multiply(a).add(x2.multiply(b)))
    rhs = apply_system(x1).multiply(a).add(apply_system(x2).multiply(b))
    return _max_diff(lhs, rhs)


def test_time_invariance(apply_system, x, k):
    """Return max |T{x[n-k]} - y[n-k]| where y = T{x}.
    apply_system is any callable: DiscreteSignal -> DiscreteSignal."""
    y_shifted = apply_system(x).shift(k)
    y2        = apply_system(x.shift(k))
    return _max_diff(y_shifted, y2)


# ================================================================
# SECTION 5 — SIGNAL ANALYSIS HELPERS
# ================================================================

def even_part(x):
    """Return x_e[n] = (x[n] + x[-n]) / 2."""
    return x.add(x.reverse()).multiply(0.5)


def odd_part(x):
    """Return x_o[n] = (x[n] - x[-n]) / 2."""
    return x.subtract(x.reverse()).multiply(0.5)


def matched_filter(template):
    """Return LTISystem with impulse response h[n] = template[-n].
    Output peaks at n = n0 (template start position) with value = template energy."""
    return LTISystem(template.reverse())


def find_peak(signal, start, end):
    """Return the time index where signal achieves its maximum over [start, end]."""
    peak_n   = start
    peak_val = signal.get_value_at_time(start)
    for n in range(start + 1, end + 1):
        v = signal.get_value_at_time(n)
        if v > peak_val:
            peak_val = v
            peak_n   = n
    return peak_n


# ================================================================
# SECTION 6 — NON-LTI SYSTEM STUBS
# Adapt these to match whatever the exam specifies.
# ================================================================

def system_b(x):
    """Time-varying amplifier: y_B[n] = n · x[n].
    Property: LINEAR but NOT time-invariant."""
    result = DiscreteSignal(x.start_time, x.end_time)
    for t in x.times():
        result.set_value_at_time(t, t * x.get_value_at_time(t))
    return result


def system_c(x):
    """Square-law device: y_C[n] = x[n]².
    Property: TIME-INVARIANT but NOT linear."""
    result = DiscreteSignal(x.start_time, x.end_time)
    for t in x.times():
        result.set_value_at_time(t, x.get_value_at_time(t) ** 2)
    return result


def system_d(x):
    """Modulator: y_D[n] = x[n] · cos(π·n/4).
    Property: LINEAR but NOT time-invariant."""
    result = DiscreteSignal(x.start_time, x.end_time)
    for t in x.times():
        result.set_value_at_time(
            t, x.get_value_at_time(t) * np.cos(np.pi * t / 4)
        )
    return result


# ================================================================
# SECTION 7 — DISPLAY HELPERS
# ================================================================

def print_signal(sig, name, start=None, end=None):
    """Print signal values in a neat column."""
    s = start if start is not None else sig.start_time
    e = end   if end   is not None else sig.end_time
    print(f"\n{name}:")
    for n in range(s, e + 1):
        print(f"  n = {n:4d}   value = {sig.get_value_at_time(n):10.4f}")
    print()


def print_comparison(col_names, signals, start, end):
    """Print multiple signals side by side over [start, end].
    col_names: list of strings (first is 'n', rest are signal labels).
    signals: list of DiscreteSignal objects, matching col_names[1:]."""
    w = 12
    header = f"{'n':>5}" + "".join(f"{c:>{w}}" for c in col_names)
    print(header)
    print("-" * len(header))
    for n in range(start, end + 1):
        row = f"{n:>5}" + "".join(
            f"{sig.get_value_at_time(n):>{w}.4f}" for sig in signals
        )
        print(row)
    print()


def plot_signals(signals_and_titles, save_path, obs_start=None, obs_end=None):
    """Plot multiple signals as stem plots and save to file.

    Args:
        signals_and_titles: list of (DiscreteSignal, title_string) pairs.
        save_path:          output PNG path.
        obs_start/obs_end:  optional observation window override.
    """
    n_plots = len(signals_and_titles)
    fig, axes = plt.subplots(
        n_plots, 1,
        figsize=(10, 3 * n_plots),
        constrained_layout=True
    )
    if n_plots == 1:
        axes = [axes]

    for ax, (sig, title) in zip(axes, signals_and_titles):
        s   = obs_start if obs_start is not None else sig.start_time
        e   = obs_end   if obs_end   is not None else sig.end_time
        ns  = list(range(s, e + 1))
        vs  = [sig.get_value_at_time(n) for n in ns]
        ml, sl, bl = ax.stem(ns, vs)
        ml.set_markersize(6)
        bl.set_color("black")
        bl.set_linewidth(1)
        ax.axhline(0, color="black", linewidth=0.8)
        ax.set_title(title)
        ax.set_xlabel("n")
        ax.set_ylabel("value")
        ax.grid(True, alpha=0.35)
        ax.set_xticks(readable_time_ticks(ns))
        ax.tick_params(axis="x", labelsize=9)

    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"Saved: {save_path}")


# ================================================================
# MAIN — fill in the exam problem here
# ================================================================

def main():
    os.makedirs("outputs", exist_ok=True)

    # ------ 1. Construct signals ------
    # x  = make_signal(-2, 8, [2, -1, 3, 1, -2, 0, 0, 0, 0, 0, 0])
    # h1 = make_signal(0, 1, [1, -1])                    # first difference
    # h2 = make_signal(0, 10, [1.0] * 11)                # finite-window accumulator

    # ------ 2. Build systems ------
    # sys1 = LTISystem(h1)
    # sys2 = LTISystem(h2)

    # ------ 3. Cascade / combine ------
    # outputs    = apply_cascade([sys1, sys2], x)
    # v, y       = outputs[0], outputs[-1]

    # ------ 4. Verify ------
    # diff = max_absolute_difference_in_range(y, x, -2, 8)
    # print(f"Max absolute difference: {diff:.2e}")
    # print(f"is_causal(sys1): {sys1.is_causal()}")

    # ------ 5. Print ------
    # print_comparison(
    #     col_names=["x[n]", "v[n]", "y[n]"],
    #     signals=[x, v, y],
    #     start=-2, end=8
    # )

    # ------ 6. Generic tests (for non-LTI systems) ------
    # x1 = make_signal(-2, 2, [1, 0, 2, -1, 3])
    # x2 = make_signal(-1, 3, [2, -3, 0, 1, 1])
    # a, b, k = 2, -3, 3
    # print(f"System B linearity:        {test_linearity(system_b, x1, x2, a, b):.6f}")
    # print(f"System B time-invariance:  {test_time_invariance(system_b, x1, k):.6f}")

    # ------ 7. Plot ------
    # plot_signals(
    #     [(x, "Input x[n]"), (v, "Intermediate v[n]"), (y, "Output y[n]")],
    #     save_path="outputs/result.png",
    #     obs_start=-2, obs_end=8
    # )

    # ------ 8. Conclude ------
    # print("Conclusion: ...")

    pass


if __name__ == "__main__":
    main()
